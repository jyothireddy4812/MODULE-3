package com.capg.walletdao;

import javax.persistence.EntityManager;

import org.junit.Assert;
import org.junit.Test;

import com.capg.walletBeans.WalletBean;

public class JUnit {
	 EntityManager con;
	    ConnectionDatabase cd=new ConnectionDatabase();
	   
	    WalletBean wb;//object of WalletBean class

	    @Test// getting Balance of account holder by reference to their accno
	    public void getBalance() { 
	        con = cd.getConnection();
	        con.getTransaction().begin();
	        WalletBean emp1=(WalletBean) con.find(WalletBean.class,new Long(5));
	        con.getTransaction().commit();
	        long observed= emp1.getBalance();
	        long expected=19604;
	        Assert.assertEquals(expected, observed); 
	    }
	    
	    }
	

