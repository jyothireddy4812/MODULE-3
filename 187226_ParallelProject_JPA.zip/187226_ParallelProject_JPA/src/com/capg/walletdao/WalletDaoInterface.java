package com.capg.walletdao;


import com.capg.walletBeans.WalletBean;

public interface WalletDaoInterface {
	
	long getBalance(long accNo) ;

	void setBalance(long accNo, long bal, String st);

	long setData(WalletBean bb);

	String getTransaction(long accNo);

	boolean passwordCheck(String str, long accNo);

	boolean accCheck(long accNo);
}
