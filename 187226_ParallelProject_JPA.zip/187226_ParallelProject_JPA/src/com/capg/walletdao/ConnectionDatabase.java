package com.capg.walletdao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ConnectionDatabase {
	public EntityManager getConnection() {
EntityManagerFactory factory=Persistence.createEntityManagerFactory("wallet");
	EntityManager entity=factory.createEntityManager();
	return entity;
	}

}