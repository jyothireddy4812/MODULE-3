package com.capg.walletdao;


import javax.persistence.EntityManager;

import com.capg.walletBeans.WalletBean;

public class WalletDao implements WalletDaoInterface {
	EntityManager connect;
	ConnectionDatabase data=new ConnectionDatabase();
	@Override
	public long getBalance(long accNo) {		
		connect = data.getConnection();
		connect.getTransaction().begin();
		WalletBean emp1=(WalletBean) connect.find(WalletBean.class,new Long(accNo));
		connect.getTransaction().commit();
		return emp1.getBalance();
	}
	@Override
	public void setBalance(long accNo, long bal, String string){
		connect = data.getConnection();
		connect.getTransaction().begin();
		WalletBean emp1=(WalletBean) connect.find(WalletBean.class,new Long(accNo));
		String str = emp1.getTransaction() + string;
		emp1.setTransaction(str);
		emp1.setBalance(bal);
		connect.merge(emp1);
		connect.getTransaction().commit();
	}
	@Override
	public boolean passwordCheck(String str,long accNo)  {
		connect = data.getConnection();
		connect.getTransaction().begin();
		WalletBean emp1=(WalletBean) connect.find(WalletBean.class,new Long(accNo));
		if (emp1.getPassword().equals(str))
			return true;
		else
			return false;
	}
	@Override
	public boolean accCheck(long accNo){
		connect = data.getConnection();
		connect.getTransaction().begin();
		WalletBean emp1=(WalletBean) connect.find(WalletBean.class,new Long(accNo));
		
		if (emp1==null)
			return false;
		else
			return true;

	}

	@Override
	public long setData(WalletBean wb) {
		connect = data.getConnection();
		connect.getTransaction().begin();
		connect.persist(wb);
		connect.getTransaction().commit();
		return wb.getAccNo();
	}

	@Override
	public String getTransaction(long accNo) {

		connect = data.getConnection();
		connect.getTransaction().begin();
		WalletBean emp1=(WalletBean) connect.find(WalletBean.class,new Long(accNo));
		connect.getTransaction().commit();
		return emp1.getTransaction();
	}

	
}
