package com.capg.walletService;

import com.capg.walletBeans.WalletBean;
import com.capg.walletdao.WalletDao;


class MyException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String s1;

	MyException(String s) {
		s1 = s;

	}

	public String toString() {
		return (s1);
	}

}

public class WalletService implements WalletServiceInterface {
	WalletDao dao = new WalletDao();

	@SuppressWarnings("unused")
	@Override
	public boolean validateName(String userName) {
		int n = userName.length();
		char[] ch = userName.toCharArray();
		for (int i = 0; i < n; i++) {
			try {
				if (ch[i] > 64 && ch[i] < 122 && ch[0]>63 && ch[0]<90) {
					return true;
				} else {
					throw new MyException("Please Enter valid Username");
				}
			} catch (MyException E) {
				System.out.println(E);
				return false;
			}

		}
		return false;
	}

	@Override
	public String addAccount(String userName, long mobile,  String password)
			 {
		WalletBean wb = new WalletBean(userName, mobile, password, 20000,"Account Created Successfully\n Available account balance :20000 /-");
			long accNo=dao.setData(wb);
			return " Account Created Successfully to our XYZ Bank Account \n Your Account number is " + accNo;
			 }

	@Override
	public long getBalance(long accNo) {
		long acc = dao.getBalance(accNo);
		return acc;

	}

	@Override
	public String getTransaction(long accNo) {
		String str = dao.getTransaction(accNo);
		return str;

	}

	@Override
	public void setBalance(long accNo, long bal, String st)  {
		dao.setBalance(accNo, bal, st);

	}

	@Override
	public boolean accCheck(long acc) {
		try {
			if (dao.accCheck(acc)) {

				return true;
			}

			else
				throw new MyException("Invalid Account Number \n Account doesn't exists or Create new Account");
		} catch (MyException E) {
			System.out.println(E);
		}
		return false;
	}

	@Override
	public boolean passwordCheck(String str,long accNo) {
		try {
			if (dao.passwordCheck(str,accNo)) {

				return true;
			} else
				throw new MyException("Wrong Password");
		} catch (MyException E) {
			System.out.println(E);
		}
		return false;
	}
	@Override
	public boolean validateMobile(long mob) {
		String s = Long.toString(mob);
		int n = s.length();
		try {
			if (n == 10) {
				return true;
			} else {
				throw new MyException("Please Enter valid Mobile Number");
			}
		} catch (MyException E) {
			System.out.println(E);
			return false;
		}

	}

	@Override
	public boolean validatePassword(String password) {
		try {
			if (password.length() >= 8) {
				return true;
			} else {
				throw new MyException("Invalid Password \n Enter atleast 8 characters");
			}
		} catch (MyException E) {
			System.out.println(E);
			return false;
		}

	}



}
