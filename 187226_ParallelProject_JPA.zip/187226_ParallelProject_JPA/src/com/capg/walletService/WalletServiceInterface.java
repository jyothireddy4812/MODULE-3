package com.capg.walletService;



public interface WalletServiceInterface {

	long getBalance(long accNo);

	String getTransaction(long accNo);

	void setBalance(long accNo, long bal, String st) ;


	String addAccount(String userName, long mobile, String password) ;

	boolean validateName(String userName);

	boolean accCheck(long acc);

	boolean passwordCheck(String str, long accNo);

	boolean validateMobile(long mob);

	boolean validatePassword(String password);


}
